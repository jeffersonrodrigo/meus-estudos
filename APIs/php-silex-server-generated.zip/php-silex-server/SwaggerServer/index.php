<?php
require_once __DIR__ . '/vendor/autoload.php';

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Silex\Application;

$app = new Silex\Application();


$app->GET('/v1/users', function(Application $app, Request $request) {
            return new Response('How about implementing usersGet as a GET method ?');
            });


$app->DELETE('/v1/users/{id}', function(Application $app, Request $request, $id) {
            return new Response('How about implementing usersIdDelete as a DELETE method ?');
            });


$app->GET('/v1/users/{id}', function(Application $app, Request $request, $id) {
            return new Response('How about implementing usersIdGet as a GET method ?');
            });


$app->PATCH('/v1/users', function(Application $app, Request $request) {
            return new Response('How about implementing usersPatch as a PATCH method ?');
            });


$app->POST('/v1/users', function(Application $app, Request $request) {
            return new Response('How about implementing usersPost as a POST method ?');
            });


$app->PUT('/v1/users', function(Application $app, Request $request) {
            return new Response('How about implementing usersPut as a PUT method ?');
            });


$app->run();
