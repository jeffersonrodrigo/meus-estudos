# Swagger\Server\Api\UsersApiInterface

All URIs are relative to *https://api.meusite.com/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**usersGet**](UsersApiInterface.md#usersGet) | **GET** /users | Lista dos Usuários
[**usersIdDelete**](UsersApiInterface.md#usersIdDelete) | **DELETE** /users/{id} | Apagar um usuário
[**usersIdGet**](UsersApiInterface.md#usersIdGet) | **GET** /users/{id} | Mostra apenas um usuário
[**usersPatch**](UsersApiInterface.md#usersPatch) | **PATCH** /users | Atualiza um usuário
[**usersPost**](UsersApiInterface.md#usersPost) | **POST** /users | Cria um usuário
[**usersPut**](UsersApiInterface.md#usersPut) | **PUT** /users | Atualiza um usuário


## Service Declaration
```yaml
# src/Acme/MyBundle/Resources/services.yml
services:
    # ...
    acme.my_bundle.api.users:
        class: Acme\MyBundle\Api\UsersApi
        tags:
            - { name: "swagger_server.api", api: "users" }
    # ...
```

## **usersGet**
> Swagger\Server\Model\User usersGet()

Lista dos Usuários

Este endpoint retorna **todos** os usuários cadastrados no sistema.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UsersApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\UsersApiInterface;

class UsersApi implements UsersApiInterface
{

    // ...

    /**
     * Implementation of UsersApiInterface#usersGet
     */
    public function usersGet()
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Swagger\Server\Model\User**](../Model/User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **usersIdDelete**
> usersIdDelete($id)

Apagar um usuário

Este endpoint **apaga o usuário a qual foi informado o id**.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UsersApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\UsersApiInterface;

class UsersApi implements UsersApiInterface
{

    // ...

    /**
     * Implementation of UsersApiInterface#usersIdDelete
     */
    public function usersIdDelete($id)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID du usuário |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **usersIdGet**
> Swagger\Server\Model\User usersIdGet($id)

Mostra apenas um usuário

Este endpoint retorna **apenas o usuário a qual foi informado o id**.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UsersApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\UsersApiInterface;

class UsersApi implements UsersApiInterface
{

    // ...

    /**
     * Implementation of UsersApiInterface#usersIdGet
     */
    public function usersIdGet($id)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| ID du usuário |

### Return type

[**Swagger\Server\Model\User**](../Model/User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **usersPatch**
> Swagger\Server\Model\User usersPatch($user)

Atualiza um usuário

Este endpoint **atualiza um usuário** no sistema. O ID do usuário deve ser informado.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UsersApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\UsersApiInterface;

class UsersApi implements UsersApiInterface
{

    // ...

    /**
     * Implementation of UsersApiInterface#usersPatch
     */
    public function usersPatch(User $user)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user** | [**Swagger\Server\Model\User**](../Model/User.md)| Usuário |

### Return type

[**Swagger\Server\Model\User**](../Model/User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **usersPost**
> Swagger\Server\Model\User usersPost($user)

Cria um usuário

Este endpoint **cria um usuário** no sistema.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UsersApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\UsersApiInterface;

class UsersApi implements UsersApiInterface
{

    // ...

    /**
     * Implementation of UsersApiInterface#usersPost
     */
    public function usersPost(User $user)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user** | [**Swagger\Server\Model\User**](../Model/User.md)| Usuário |

### Return type

[**Swagger\Server\Model\User**](../Model/User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

## **usersPut**
> Swagger\Server\Model\User usersPut($user)

Atualiza um usuário

Este endpoint **atualiza um usuário** no sistema. O ID do usuário deve ser informado.

### Example Implementation
```php
<?php
// src/Acme/MyBundle/Api/UsersApiInterface.php

namespace Acme\MyBundle\Api;

use Swagger\Server\Api\UsersApiInterface;

class UsersApi implements UsersApiInterface
{

    // ...

    /**
     * Implementation of UsersApiInterface#usersPut
     */
    public function usersPut(User $user)
    {
        // Implement the operation ...
    }

    // ...
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user** | [**Swagger\Server\Model\User**](../Model/User.md)| Usuário |

### Return type

[**Swagger\Server\Model\User**](../Model/User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

